from setuptools import setup, find_packages

setup(
    name="tea-alpha",
    version="0.0.1",
    keywords=['Exception'],
    license='MIT license',
    author="alphagot812",
    author_email="alphagot@163.com",
    install_requires=[],
    url="https://github.com/alphagot812/tea-alpha",
    packages=find_packages(),
    description="Exception"
)
